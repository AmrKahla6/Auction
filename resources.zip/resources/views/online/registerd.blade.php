@extends('layouts.online.member')

@section('content')
@include('online.profile.myauctions');
@endsection