<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AuctionType extends Model
{
    protected $guarded = [];
}
