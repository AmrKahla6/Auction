<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StaticDayOF extends Model
{
    protected $guarded=[];
}
